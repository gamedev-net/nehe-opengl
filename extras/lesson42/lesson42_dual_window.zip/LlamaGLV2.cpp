//***********************************************************************************************
//***********************************************************************************************
//**                                                                                           **
//**                           LlamaGL Basecode Version 2 Beta 1                               **
//**                                 Author: LlamaGuy                                          **
//**                                                                                           **
//**    The first truly object-oriented base code. Supports multiple viewports and windows.    **
//**                                                                                           **
//**   Keep in mind: Seperate windows use different RCs, so textures\GL settings do not carry  **
//**    from window to window. Each window must be initialized as if it were its own program.  **
//**                                                                                           **
//**                              http://nehe.gamedev.net/                                     **
//**                                                                                           **
//***********************************************************************************************
//***********************************************************************************************

#include "LlamaGLV2.h"

//***********************************************************************************************
//***********************************************************************************************
//**                                                                                           **
//**                                      LGLWindow                                            **
//**                                                                                           **
//***********************************************************************************************
//***********************************************************************************************

int LGLWindow::numWindows=0;
int LGLWindow::currentWindow=0;

LRESULT CALLBACK LGLWindow::StaticWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LRESULT (CALLBACK LGLWindow::*wndprc)(HWND,UINT,WPARAM,LPARAM);
	LRESULT (CALLBACK *realwndprc)(void*,HWND,UINT,WPARAM,LPARAM);
	void* thisAddress;
	wndprc=WndProc;

	CopyMemory(&realwndprc, &wndprc, sizeof(void*));
	if (uMsg==WM_CREATE)
		SetWindowLong(hWnd, GWL_USERDATA, lParam+0x834);
	thisAddress=(void*)(GetWindowLong(hWnd, GWL_USERDATA));
	if (thisAddress==0)
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	return realwndprc(thisAddress, hWnd, uMsg, wParam, lParam);
}

LRESULT CALLBACK LGLWindow::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_CREATE:
		break;
	case WM_CLOSE:
		PostQuitMessage(0);
		break;
	}
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

bool LGLWindow::DoMessages()
{
	MSG		msg;

	while (PeekMessage(&msg,NULL,0,0,PM_REMOVE))
	{
		if (msg.message==WM_QUIT)
			return false;
		else
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
	return true;
}

bool LGLWindow::Show()
{
	if (myWnd==NULL)
	{
		lastError|=LGL_ERROR_NOWINDOW;
		return false;
	}

	ShowWindow(myWnd, SW_SHOW);
	SetForegroundWindow(myWnd);
	SetFocus(myWnd);

	return true;
}

bool LGLWindow::KillWindow()
{
	bool Success=true;
	if (madeByMe&&fullscreen)
		ChangeDisplaySettings(NULL,0);

	if (hRC)
	{
		wglMakeCurrent(NULL,NULL);
		if (!wglDeleteContext(hRC))
		{
			lastError|=LGL_ERROR_RELEASERC;
			Success=false;
		}
		else
			hRC=0;
	}

	if (hDC && !ReleaseDC(myWnd,hDC))
	{
		lastError|=LGL_ERROR_RELEASEDC;
		Success=false;
	}
	else
		hDC=0;

	if (!madeByMe)
		return Success;

	if (myWnd && !DestroyWindow(myWnd))
	{
		lastError|=LGL_ERROR_DESTROYWINDOW;
		Success=false;
	}
	else
		myWnd=0;
	numWindows--;

	if (numWindows==0)
	{
		if (!UnregisterClass("LlamaGLWindowV2",hInst))
		{
			lastError|=LGL_ERROR_UNREGISTERCLASS;
			Success=false;
		}
	}

	return Success;
}

bool LGLWindow::CreateGL(int bits)
{
	GLuint					pixelFormat;
	PIXELFORMATDESCRIPTOR	pixelFormatDesc=
	{
		sizeof(PIXELFORMATDESCRIPTOR),
		1,
		PFD_DRAW_TO_WINDOW|PFD_SUPPORT_OPENGL|PFD_DOUBLEBUFFER,
		PFD_TYPE_RGBA,
		bits,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 0, 
		PFD_MAIN_PLANE,
		0, 0, 0, 0
	};

	if (!(hDC=GetDC(myWnd)))
	{
		lastError|=LGL_ERROR_GETDC;
		KillWindow();
		return false;
	}

	if (!(pixelFormat=ChoosePixelFormat(hDC,&pixelFormatDesc)))
	{
		lastError|=LGL_ERROR_GETPFD;
		KillWindow();
		return false;
	}

	if(!SetPixelFormat(hDC, pixelFormat, &pixelFormatDesc))
	{
		lastError|=LGL_ERROR_SETPFD;
		KillWindow();
		return false;
	}

	if (!(hRC=wglCreateContext(hDC)))
	{
		lastError|=LGL_ERROR_CREATEWGL;
		KillWindow();
		return false;
	}

	if(wglMakeCurrent(hDC,hRC)==false)
	{
		lastError|=LGL_ERROR_MAKECURRENTWGL;
		KillWindow();
		return false;
	}
	currentWindow=myNum;
	return true;
}

LGLWindow::LGLWindow()
{
	LGLWindow("OpenGL", 0, 0, 800, 600, false, 16);
}

LGLWindow::LGLWindow(char* title, int left, int top, int width, int height, bool fullscreenp, int bits)
{
	WNDCLASSEX				winClass;
	RECT					winRect;

	myWnd=0;
	hDC=0;
	lastError=0;
	fullscreen=fullscreenp;
	madeByMe=true;
	hInst=GetModuleHandle(NULL);
	SetRect(&winRect,0,0,0,0);

	ZeroMemory(&winClass, sizeof(WNDCLASSEX));
	winClass.cbSize=sizeof(WNDCLASSEX);
	winClass.style=CS_HREDRAW|CS_VREDRAW|CS_OWNDC;
	winClass.lpfnWndProc=StaticWndProc;
	winClass.hInstance=hInst;
	winClass.hbrBackground=(HBRUSH)(COLOR_APPWORKSPACE);
	winClass.hCursor=LoadCursor(NULL, IDC_ARROW);
	winClass.lpszClassName="LlamaGLWindowV2";

	if (numWindows==0)
	{
		if (!RegisterClassEx(&winClass))
		{
			lastError|=LGL_ERROR_REGISTERCLASS;
			return;
		}
	}

	if (fullscreen)
	{
		DEVMODE dmScreenSettings;
		memset(&dmScreenSettings, 0, sizeof(dmScreenSettings));
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);
		dmScreenSettings.dmPelsWidth=width;
		dmScreenSettings.dmPelsHeight=height;
		dmScreenSettings.dmBitsPerPel=bits;
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;
		if (ChangeDisplaySettings(&dmScreenSettings, CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			lastError|=LGL_ERROR_CHANGESCREEN;
			KillWindow();
			return;
		}
	}
	else
	{
		AdjustWindowRectEx(&winRect, WS_OVERLAPPEDWINDOW, false, WS_EX_APPWINDOW);
		winRect.right-=winRect.left;
		winRect.bottom-=winRect.top;
	}

	myWnd=CreateWindowEx(fullscreen?WS_EX_APPWINDOW|WS_EX_TOPMOST:WS_EX_APPWINDOW,
						"LlamaGLWindowV2",
						title,
						fullscreen?WS_POPUP:WS_OVERLAPPEDWINDOW|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,
						left,
						top,
						winRect.right+width,
						winRect.bottom+height,
						HWND_DESKTOP,
						NULL,
						hInst,
						this);
	if (myWnd==NULL)
	{
		lastError|=LGL_ERROR_CREATEWINDOW;
		KillWindow();
		return;
	}

	numWindows++;
	myNum=numWindows;
	currentWindow=myNum;

	CreateGL(bits);
	InitGL();

	DoMessages();
}

bool LGLWindow::SetDimensions(int width, int height)
{
	return true;
}

bool LGLWindow::SetPosition(int left, int top)
{
	return true;
}

HWND LGLWindow::hWnd()
{
	return myWnd;
}

void LGLWindow::InitGL()
{
	glEnable(GL_TEXTURE_2D);
	glShadeModel(GL_SMOOTH);
	glClearColor(0.0f,0.0f,0.0f,0.0f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);
	glHint(GL_POINT_SMOOTH_HINT,GL_NICEST);
}

bool LGLWindow::Select()
{
	if (myNum==currentWindow)
		return true;
	if(wglMakeCurrent(hDC,hRC)==false)
	{
		lastError|=LGL_ERROR_MAKECURRENTWGL;
		return false;
	}
	currentWindow=myNum;
	return true;
}

void LGLWindow::UpdateScreen()
{
	Select();
	SwapBuffers(hDC);
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
}

LGLWindow::~LGLWindow()
{
	KillWindow();
}

unsigned long LGLWindow::GetLastError()
{
	unsigned long ret=lastError;
	lastError=0;
	return ret;
}

//***********************************************************************************************
//***********************************************************************************************
//**                                                                                           **
//**                                     LGLViewport                                           **
//**                                                                                           **
//***********************************************************************************************
//***********************************************************************************************

int LGLViewport::currentViewport=0;
int LGLViewport::numViewports=0;

LGLViewport::LGLViewport(LGLWindow* Win, int left, int top, int width, int height)
{
	HWND hWnd=Win->hWnd();
	if (hWnd==NULL)
	{
		active=false;
		return;
	}
	numViewports++;
	myNum=numViewports;
	currentViewport=0;
	active=true;
	myX=left;
	myY=top;
	myWidth=width;
	myHeight=height;
	myParent=Win;
	PerspectiveView();
	Select();
}

LGLViewport::LGLViewport(LGLWindow* Win)
{
	HWND hWnd=Win->hWnd();
	RECT r;
	myWnd=Win->hWnd();
	if (hWnd==NULL)
	{
		active=false;
		return;
	}
	numViewports++;
	myNum=numViewports;
	currentViewport=0;
	active=true;
	GetClientRect(myWnd, &r);
	myX=0;
	myY=0;
	myWidth=r.bottom;
	myHeight=r.right;
	myParent=Win;
	//PerspectiveView();
	Select();
}

LGLViewport::~LGLViewport()
{
}

bool LGLViewport::Select()
{
	if (!active)
		return false;
	if (myNum==currentViewport)
		return true;
	if (!myParent->Select())
		return false;
	currentViewport=myNum;

	glViewport(myX, myY, myWidth, myHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	if (myPerspective.Ortho)
		glOrtho(myPerspective.left,
				myPerspective.left+myPerspective.width,
				myPerspective.top,
				myPerspective.top+myPerspective.height,
				myPerspective.min,
				myPerspective.max);
	else
		gluPerspective(myPerspective.fovy, myPerspective.aspect, myPerspective.zNear, myPerspective.zFar);

	return true;
}

int LGLViewport::getWidth()
{
	return myWidth;
}

int LGLViewport::getHeight()
{
	return myHeight;
}

int LGLViewport::getLeft()
{
	return myX;
}

int LGLViewport::getTop()
{
	return myY;
}

void LGLViewport::PerspectiveView()
{
	PerspectiveView(45.0, (GLfloat)(myWidth)/(GLfloat)(myHeight), 0.1f, 250.0f);
}

void LGLViewport::PerspectiveView(GLdouble zNear, GLdouble zFar)
{
	PerspectiveView(45.0, (GLfloat)(myWidth)/(GLfloat)(myHeight), zNear, zFar);
}

void LGLViewport::PerspectiveView(GLdouble fovy, GLdouble aspect, GLdouble zNear, GLdouble zFar)
{
	gluPerspective(fovy, aspect, zNear, zFar);

	myPerspective.fovy=fovy;
	myPerspective.aspect=aspect;
	myPerspective.zNear=zNear;
	myPerspective.zFar=zFar;
	myPerspective.Ortho=false;
}

void LGLViewport::OrthoView()
{
	OrthoView(myX, myY, myWidth, myHeight, -0.1f, 0.1f);
}

void LGLViewport::OrthoView(GLdouble left, GLdouble top, GLdouble width, GLdouble height)
{
	OrthoView(left, top, width, height, -0.1f, 0.1f);
}

void LGLViewport::OrthoView(GLdouble left, GLdouble top, GLdouble width, GLdouble height, GLdouble min, GLdouble max)
{
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	glOrtho(left, width, height, top, min, max);

	myPerspective.left=left;
	myPerspective.top=top;
	myPerspective.width=width;
	myPerspective.height=height;
	myPerspective.min=min;
	myPerspective.max=max;
	myPerspective.Ortho=true;
}