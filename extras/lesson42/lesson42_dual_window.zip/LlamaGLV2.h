//***********************************************************************************************
//***********************************************************************************************
//**                                                                                           **
//**                           LlamaGL Basecode Version 2 Beta 1                               **
//**                                 Author: LlamaGuy                                          **
//**                                                                                           **
//**    The first truly object-oriented base code. Supports multiple viewports and windows.    **
//**                                                                                           **
//**   Keep in mind: Seperate windows use different RCs, so textures\GL settings do not carry  **
//**    from window to window. Each window must be initialized as if it were its own program.  **
//**                                                                                           **
//**                              http://nehe.gamedev.net/                                     **
//**                                                                                           **
//***********************************************************************************************
//***********************************************************************************************

//**
//** Upcoming features:
//**
//** - Documentation ;)
//** - Cleaned up code
//** - Texture loaders
//** - Custom callbacks
//** - Maybe a texture class that's universal for all windows
//** - Accessors\modifiers for the classes
//** - Keyboard\mouse input
//** - Anything else I think of
//** - Send feedback to LlamaGuy@Cox.net
//**

//** "Basecode should be usable in all situations with no modifications to the basecode."

#ifndef LGLBASECODE
#define LGLBASECODE
#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")

#define LGL_ERROR_RELEASEDC				1
#define LGL_ERROR_DESTROYWINDOW			2
#define LGL_ERROR_UNREGISTERCLASS		4
#define LGL_ERROR_CREATEWINDOW			8
#define LGL_ERROR_CHANGESCREEN			16
#define LGL_ERROR_REGISTERCLASS			32
#define LGL_ERROR_RELEASERC				64
#define LGL_ERROR_GETDC					128
#define LGL_ERROR_GETPFD				256
#define LGL_ERROR_SETPFD				512
#define LGL_ERROR_CREATEWGL				1024
#define LGL_ERROR_MAKECURRENTWGL		2048
#define LGL_ERROR_UNKNOWN				5096
#define LGL_ERROR_NOWINDOW				10192

typedef struct
{
	GLdouble fovy, aspect, zNear, zFar;
	GLdouble left, top, width, height, min, max;
	bool Ortho;
} LGLPerspective;

class LGLWindow
{
	friend class LGLViewport;
	private:
	    HWND				myWnd;
		HDC					hDC;
		HGLRC				hRC;
		HINSTANCE			hInst;
		unsigned long		lastError;
		bool				fullscreen;
		bool				madeByMe;
		static int			numWindows;
		static int			currentWindow;
		int					myNum;
	public:
	    LGLWindow();
		LGLWindow(char* title, int top, int left, int width, int height, bool fullscreenp, int bits);
	    ~LGLWindow();
		bool KillWindow();
		bool Show();
		bool SetDimensions(int width, int height);
		bool SetPosition(int left, int top);
		static bool DoMessages();
		HWND hWnd();
		void UpdateScreen();
		unsigned long GetLastError();
		bool Select();
	private:
		bool CreateGL(int bits);
		void InitGL();
		static LRESULT CALLBACK StaticWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
		LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
};

class LGLViewport
{
	private:
	    HWND				myWnd;
		LGLWindow*			myParent;
		int					myX, myY;
		int					myWidth, myHeight;
		bool				ortho;
		bool				active;
		int					myNum;
		static int			currentViewport;
		static int			numViewports;
		LGLPerspective		myPerspective;
	public:
		//LGLViewport();
		LGLViewport(LGLWindow* Win, int left, int top, int width, int height);
		LGLViewport(LGLWindow* Win);
	    ~LGLViewport();
		int getWidth();
		int getHeight();
		int getLeft();
		int getTop();
		bool Select();
		void OrthoView();
		void OrthoView(GLdouble left, GLdouble top, GLdouble width, GLdouble height);
		void OrthoView(GLdouble left, GLdouble top, GLdouble width, GLdouble height, GLdouble min, GLdouble max);
		void PerspectiveView();
		void PerspectiveView(GLdouble zNear, GLdouble zFar);
		void PerspectiveView(GLdouble fovy, GLdouble aspect, GLdouble zNear, GLdouble zFar);
	private:
		static LRESULT CALLBACK StaticWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
};
#endif