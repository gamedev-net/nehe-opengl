//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Lesson38Saver.rc
//
#define IDS_STR_DESCRIP                 1
#define IDABOUT                         3
#define IDI_ICON_SCREEN                 100
#define IDB_BUTTERFLY1                  103
#define IDB_BUTTERFLY2                  104
#define IDB_BUTTERFLY3                  105
#define IDI_ICON                        106
#define IDD_DLG_ABOUT                   107
#define ROTATE                          1000
#define WEBPAGE1                        1001
#define WEBPAGE2                        1002
#define IDD_DLG_SCREEN                  2003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
